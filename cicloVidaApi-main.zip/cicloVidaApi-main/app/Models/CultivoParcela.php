<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CultivoParcela extends Model
{
    use HasFactory;

    protected $table = 'cultivo_parcela';

    protected $fillable = [
        'id',
        'id_parcela',
        'id_cultivo',
        'created_at',
        'updated_at',
        'fecha_baja',
        'fecha_siembra',
        'fecha_recoleccion',
        'espaldera',
        'sistema_riego',
        'bomba',
        'entre_arboles',
        'entre_calles',
        'superficie_cultivada',
        'produccion_t_ha',
        'informe_impacto', //archivo BIGblob -- no debe cargarse hasta que no obtenemos por id el cultivo
    ];

    // Relaciones directas con otros modelos
    public function parcela()
    {
        return $this->belongsTo(Parcela::class, 'id_parcela');
    }

    public function cultivo()
    {
        return $this->belongsTo(Cultivo::class, 'id_cultivo', 'id');
    }

    public function espaldera()
    {
        return $this->belongsTo(Espaldera::class, 'espaldera');
    }

    public function sistemaRiego()
    {
        return $this->belongsTo(Riego::class, 'sistema_riego');
    }

    public function grupoBombeo()
    {
        return $this->belongsTo(GrupoBombeo::class, 'bomba');
    }

    // Relaciones muchos a muchos
    public function fertilizantes()
    {
        return $this->hasMany(Fertilizante::class, 'id_cultivo_parcela', 'id');
    }

    public function fitosanitarios()
    {
        return $this->belongsToMany(Fitosanitario::class, 'fitosanitarios_cultivo', 'id_cultivo_parcela', 'id_fitosanitario');
//->withPivot(['n_aplicaciones','fecha'] ); // Ajusta 'dosis' según el campo en la tabla pivote
    }

    public function aperos()
    {
        return $this->belongsToMany(Apero::class, 'aperos_cultivo', 'id_cultivo_parcela', 'id_apero');
           // ->withPivot('pases', 'fecha');
    }

    public function maquinas()
    {
        return $this->belongsToMany(Maquina::class, 'maquinaria_cultivo', 'id_cultivo_parcela', 'id_maquina') ;//->withPivot(['horas', 'fecha']);
          
        // return $this->hasMany(MaquinaCultivo::class, 'id_cultivo_parcela', 'id');
    }
}
