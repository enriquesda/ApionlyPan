<?php

namespace App\Http\Controllers;


    use App\Models\User;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Hash;
    use Illuminate\Validation\ValidationException;
    use Illuminate\Support\Facades\Password;
    use Tymon\JWTAuth\Facades\JWTAuth ;
    use Tymon\JWTAuth\Exceptions\JWTException;
    use Illuminate\Support\Facades\Auth;
    use App\Models\Agricultor;
    Use Exception;
    
 class UsersController extends Controller
{
        // Registro de un nuevo usuario
        public function registroUsuario(Request $request)
        {
                $request->validate([
                    'nombre' => 'required|string',
                    'email' => 'required|email|unique:users',
                    'password' => 'required|string|confirmed',
                ]);
        
                $user = new User([
                    'nombre' => $request->nombre,
                    'email' => $request->email,
                    'password' => Hash::make($request->password),
                    'rol' => 'usuario' // Por defecto, un nuevo usuario tendrá el rol 'usuario'
                ]);
        
                $user->save();
        
                return response()->json(['message' => 'Usuario registrado con exito'], 201);
        }
    
        // Iniciar sesión (Login)
        public function login(Request $request)
        {
            try{

              
                $credentials = $request->only('email', 'password');
                try {
                    if (!$token = JWTAuth::attempt($credentials)) {
                        return response()->json(['error' => 'Credenciales inválidas'], 400);
                    }
                } catch (JWTException $e) {
                    return response()->json(['error' => 'No se pudo crear el token'], 500);
                }
                // $user = Auth::user();
                // $user['token'] = $token;
                // $user ['agricultor'] = Agricultor::where('id_usuario', $user->id)->get()->first();
                return response()->json(compact('token'),200);
            } catch (Exception $e){
                return response () -> json (['status' => 403, 'mensaje' => $e->getMessage()]);
            }
        }
    
        // Crear un nuevo usuario (solo por administradores)
        public function crearUsuario(Request $request)
        {
            try{
                //$this->authorizeAdmin();
        
                $request->validate([
                    'nombre' => 'required|string',
                    'email' => 'required|email|unique:users',
                    'password' => 'required|string|confirmed',
                    'rol' => 'required|numeric|in:1,2,3', //1 super admin , 2 admin, 3 usuario agricultor (solo el superadmin puede crear otros super y admins) y el admin puede crear usuarios
                ]);
        
                $user = new User([
                    'nombre' => $request -> nombre,
                    'email' => $request->email,
                    'password' => Hash::make($request->password),
                    'rol' => $request->rol,
                    'created_at' => now(),
                ]);
               
                $user->save();
        
                return response()->json(['message' => 'Usuario creado con exito'], 201);
            } catch (ValidationException $e) {
                // Manejo específico de la excepción de validación
                $errors = $e->validator->errors();
                return response()->json(['errores' => $errors], 422);
        
            } catch (Exception $e) {
                // Manejo de cualquier otra excepción
                return response()->json([
                    'message' => 'Ocurrió un error inesperado.',
                    'error' => $e->getMessage()
                ], 500);
            }
        }
        public function registrarUsuarioAgricultor (Request $request){
            try{
                //$this->authorizeAdmin();
        
                $request->validate([
                    'nombre' => 'required|string',
                    'email' => 'required|email|unique:users',
                    'password' => 'required|string|confirmed',
                    
                ]);
        
                $user = new User([
                    'nombre' => $request -> nombre,
                    'email' => $request->email,
                    'password' => Hash::make($request->password),
                    'dni' => $request -> dni ?? null,
                    'telefono' => $request -> telefono ?? null,
                    'n_referencia' => null,
                    'rol' => 3,
                    'created_at' => now(),
                ]);
                
                $user->save();
                // $ag = new Agricultor  ([
                //     'referencia_junta' => $request['agricultor']['referencia_junta'] ?? null,
                //     'id_usuario' => $user->id,
                //     'telefono' => $request['agricultor']['telefono'] ?? null,
                //     'created_at' => now()
                // ]) ;
                // $ag -> save();
                // $user['agricultor']= $ag;
        
                return response()->json(['message' => 'Registro completado', 'user'=>$user, 'status'=>201], 201);
            } catch (ValidationException $e) {
                // Manejo específico de la excepción de validación
                $errors = $e->validator->errors();
                return response()->json(['errores' => $errors], 422);
        
            } catch (Exception $e) {
                // Manejo de cualquier otra excepción
                return response()->json([
                    'message' => 'Error del servidor contacte con nosotros.',
                    'error' => $e->getMessage()
                ], 500);
            }
        }
    
        public function validaUsuario () {
            try{
                if (!$user = JWTAuth::parseToken()->authenticate()) {
                    return response () -> json (['status' => 403, 'mensaje' => 'Ha ocurrido un error. No se reconoce al usuario']);
                }
                // $user ['agricultor'] = Agricultor::where('id_usuario', $user->id)->get()->first();
                return response () -> json (['status' => 200, 'mensaje' => 'Usuario valido', 'user' => $user]);
            } catch (Exception $e){
                return response () -> json (['status' => 403, 'mensaje' => $e->getMessage()]);
            }
        }
        // Eliminar cuenta (por el propio usuario)
        public function eliminarCuenta()
        {
            try{
                 $user = Auth::user();
                $user->fecha_baja = now();
                return response()->json(['message' => 'Cuenta eliminada con exito'], 200);
            } catch (Exception $e){
                return response () -> json (['status' => 403, 'mensaje' => $e->getMessage()]);
            }
        }
    
        // Eliminar un usuario (solo por administradores)
        public function eliminarUsuario($id)
        {
            try{
                $this->authorizeAdmin();
        
                $user = User::findOrFail($id);
                $user->delete();
        
                return response()->json(['message' => 'Usuario eliminado con exito'], 200);
            } catch (Exception $e){
                return response () -> json (['status' => 403, 'mensaje' => $e->getMessage()]);
            }
        }
    
        // Cambiar contraseña (por el usuario)
        public function cambiarContrasen(Request $request)
        {
            try{
                $request->validate([
                    'password' => 'required|string|confirmed',
                ]);
        
                $user = Auth::user();
                if(get_class($user) == User::class){ //para asgurar que tenemos un objeto de la clase user obtenido de la uthenticación
                    
                    $user->password = Hash::make($request->password);
                    
                    $user->save(); //no reconoce como un obejeto de usuairo por eso Intelephense lo detecta como un error pero esta operación es válida si el usuario se authentica
                }
                return response()->json(['message' => 'Contraseña cambiada con exito'], 200);
            } catch (Exception $e){
                return response () -> json (['status' => 403, 'mensaje' => $e->getMessage()]);
            }
        }
    
            // Obtener todos los usuarios y, si son agricultores, incluir la información del agricultor
        public function obtenerUsuariosConAgricultores($idInicio = null)
        {
            // Obtener todos los usuarios y cargar la relación con agricultor si existe
            $this->authorizeAdmin();
            if ($idInicio){
                $usuarios = User::where('id','>',$idInicio)->limit(100)->get();
            }else{
                $usuarios = User::with('agricultor')->get();
            }
            

            return response()->json($usuarios, 200);
        }

        /**
         * Función para buscar usuarios dentro de la bd sin tenerlos cargados en la aplicación.
         */
        public function buscarUsuarios( $termino = null){
            // Crear la consulta para filtrar usuarios
            $query = User::query();

            if ($termino) {
                $query->where(function($query) use ($termino) {
                    $query->where('nombre', 'like', '%' . $termino . '%')
                        ->orWhere('dni', 'like', '%' . $termino . '%');
                });
            }

            
            $usuarios = $query->get();

            return response()->json($usuarios, 200);
        }
        // Editar perfil (por el usuario)
        public function editarUsuario(Request $request)
        {
            try{
               $this->authorizeAdmin();

              $u = Auth::user(); //vuelvo a obtener el ususario que está tratando de hacer la operación para comprobar si puede designar otros adminsitradores siendo este superAdmin.
              
           
                //si es super admin o admin puede editar o crear usuario
                    $usuario = User::findOrFail($request ['id']);
                    
                    $usuario -> nombre = $request ['nombre'] ??  $usuario -> nombre;
                    $usuario -> email = $request ['email'] ?? $usuario -> email;
                    $usuario -> dni = $request ['dni'] ?? $usuario -> dni; //dni o CIF si viene si no dejamos el que estaba
                    $usuario -> telefono = $request ['telefono'] ?? $usuario->telefono;
                    $usuario -> telefono = $request ['n_referencia'] ?? $usuario->n_referencia;
                    
                    if ( $u->rol == 1) { //Solo si el rol es sueper ADMIN dejamos designar otros administradores o super administradores
                        $usuario -> rol = $request ['rol'] ?? $usuario -> rol; 
                    }
                    
                    if ($usuario->save()){
                        return response()->json(['message' => 'Perfil actualizado con exito', 'usuario' => $usuario], 200);
                    }
                return response()->json(['message' => 'Failed to faind user'], 300);
            } catch (Exception $e){
                return response () -> json (['status' => 403, 'mensaje' => $e->getMessage()]);
            }
        }
    
        // Metodo privado para verificar si el usuario es administrador
        public function authorizeAdmin()
        {
            try{
               // $user = auth()->user();
                $user = Auth::user();
                if ($user->rol !== 1 || $user -> rol !== 2) {
                    return response()->json(['error' => 'Acceso no autorizado'], 403);
                }else {
                    return $user;
                }
            } catch (Exception $e){
                return response () -> json (['status' => 403, 'mensaje' => $e->getMessage()]);
            }
        }

        public function recuperarContrasen (Request $request) {
          try{ 
                $request->validate(['email' => 'required|email|exists:users,email']);
          
                $status = Password::sendResetLink(
                    $request->only('email')
                );
                if ($status === Password::RESET_LINK_SENT) {
                  
                    return response()->json(['message' => 'Enlace de restablecimiento enviado a su correo electrónico.'], 200);
                }
               
            } catch (Exception $e){
            
                return response()->json(['message' => 'Hubo un error al enviar el enlace.'], 500);
            }
         

        }
        public function updatePassword(Request $request){
            // Validación de entrada
            $request->validate([
                'token' => 'required',
                'password' => 'required|string|min:6|confirmed',
            ]);

            // Procesar el restablecimiento de la contraseña
            $status = Password::reset(
                $request->only('email', 'password', 'password_confirmation', 'token'),
                function ($user, $password) {
                    $user->forceFill([
                        'password' => Hash::make($password)
                    ])->save();
                }
            );

            if ($status === Password::PASSWORD_RESET) {
                return redirect()->away('http://localhost:8100/login')->with('status', __($status)); //esta url habrá que cambiarla cuando estemos en prod
            }
          
            return back()->withErrors(['email' => [__($status)]]);
        }
        public function logout (){
            try {

                Auth::logout();
                  // Invalidar el token del usuario actual
                  JWTAuth::invalidate(JWTAuth::getToken());
               // $user->currentAccessToken()->delete();
                //dd($user);
                return response()->json(['mensaje' => 'Deslogueado correctamente'], 200);
            } catch (Exception $e) {
                return response()->json(['mensaje' => 'Error al intentar cerrar sesión', 'error' => $e->getMessage()], 500);
            }
        }
}