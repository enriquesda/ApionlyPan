<?php

namespace App\Http\Controllers;

use App\Models\Parcela;
use App\Models\Municipio;
use App\Models\Provincia;
use App\Models\Filtro;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Illuminate\Validation\Rule;

use Exception;

class ParcelasController extends Controller
{
    /**
     * Obtiene todas las parcelas habidas y por haber en la App.
     */
    public function obtenerTodas()
    {
        $parcelas = Parcela::all();
        return response()->json($parcelas, 200);
    }

    /**
     * Obtiene todas las parcelas de un agricultor.
     */
    public function obtenerParcelasAgricultor($idAgricultor)
    {
        // $parcelas = Parcela::with(['filtros', 'cultivos'])->where('id_agricultor', $idAgricultor)->get();
        $parcelas = Parcela::with(['filtros'])->where('id_agricultor', $idAgricultor)->get();
        if ($parcelas->isEmpty()) {
            return response()->json(['message' => 'No se encontraron parcelas para el agricultor'], 404);
        }

        return response()->json($parcelas, 200);
    }

    /**
     * Crear una nueva parcela.
     */
    public function crearParcela(Request $request)
    {
        try {
            
            $request->validate([
                'id_agricultor' => 'required|exists:users,id',
                'municipio' => 'required|numeric',
                'provincia' => 'required|numeric',
                'numero_sigpac' => 'nullable|string|unique:parcelas,numero_sigpac',
                'superficie' => 'required|numeric',
                'poligono' => 'required|numeric',
                'parcela' => [
                    'required',
                    'numeric',
                    Rule::unique('parcelas')->where(function ($query) use ($request) {
                        return $query->where(['poligono' => $request->input('poligono'), 'provincia' => $request->input('provincia'), 'municipio' => $request->input('municipio') ]);
                    }),
                ],
                'zona' => 'nullable|numeric',
                'agregado' => 'nullable|numeric',
                'recinto' => 'nullable|numeric',
                'ancho_caseta' => 'nullable|numeric',
                'largo_caseta' => 'nullable|numeric',
                'alto_caseta' => 'nullable|numeric',
            ]);
    
            // Crear la nueva parcela
            $parcela = Parcela::create($request->all());

            return response()->json($parcela, 201);
        } catch (ValidationException $e) {
            // Capturamos la excepción de validación
            $errors = $e->validator->errors()->all(); // Obtener solo los mensajes de error como un array
    
            // Retornamos la respuesta en el formato deseado
            return response()->json(['status' => 422, 'errors' => $errors], 422);
        } catch (Exception $e) {
            return response()->json(['status' => 500, 'mensaje' => $e->getMessage()]);
        }
    }
    
    /**
     * Esta función recibe en la request un array con los ids de los filtros que se quieren asociar al idParcela 
     * por ejemplo:
     * { "filtros": [1, 4, 2]}
     */
   public function agregarFiltrosParcela (Request $request, $idParcela) {
        try {
            $parcela = Parcela::findOrFail($idParcela);

            // Validar los datos de entrada
            $request->validate([
                'filtros' => 'required|array',
                'filtros.*' => 'exists:filtros,id'  // Cada filtro debe existir en la tabla filtros
            ]);
    
            // Agregar los filtros a la parcela
            //$parcela->filtros()->syncWithoutDetaching($request->filtros);
            $parcela->filtros()->sync($request->filtros); //la función sync elimina los filtros relacionados con la parcela que no parectan en el array si los hubiera 
            return response()->json(['message' => 'Filtros agregados con exito a la parcela'], 200);
        } catch (Exception $e) {
            return response()->json(['status' => 500, 'mensaje' => $e->getMessage()]);
        }
   }
  
     /**
     * Esta función recibe en la request un array con los ids de los filtros que se quieren eliminar de la idParcela 
     * por ejemplo:
     * { "filtros": [1, 4, 2]}
     */
   public function actualizarFiltrosParcela(Request $request, $idParcela)
   {
       try {
           $parcela = Parcela::findOrFail($idParcela);
   
           // Validar los datos de entrada
           $request->validate([
               'filtros' => 'nullable|array',             // Puede ser un array vacío
               'filtros.*' => 'exists:filtros,id'         // Cada filtro debe existir en la tabla filtros
           ]);
   
           // Eliminar todos los filtros asociados a la parcela
           $parcela->filtros()->detach();
   
           // Agregar los nuevos filtros si se proporcionan en la solicitud
           if (!empty($request->filtros)) {
               $parcela->filtros()->attach($request->filtros);
           }
   
           return response()->json(['message' => 'Filtros actualizados con éxito para la parcela'], 200);
           
       } catch (Exception $e) {
           return response()->json(['status' => 500, 'mensaje' => $e->getMessage()]);
       }
   }

    /**
     * Editar una parcela existente.
     */
    public function editar(Request $request)
    {
        try {
            // Buscar la parcela por ID
            $parcela = Parcela::find($request['id']);
    
            if (!$parcela) {
                return response()->json(['message' => 'Parcela no encontrada'], 404);
            }
    
            // Validar el request
            $request->validate([
                'municipio' => 'nullable|numeric',
                'provincia' => 'nullable|numeric',
                'numero_sigpac' => 'nullable|string',
                'superficie' => 'nullable|numeric',
                'poligono' => 'nullable|numeric',
                'parcela' => [
                    'nullable',
                    'numeric',
                    Rule::unique('parcelas')->where(function ($query) use ($request) {
                        return $query->where(['poligono' => $request->input('poligono'), 'provincia' => $request->input('provincia'), 'municipio' => $request->input('municipio') ]);
                    })->ignore($request->id) // Ignorar la parcela actual al validar
                ],
                'zona' => 'nullable|numeric',
                'agregado' => 'nullable|numeric',
                'recinto' => 'nullable|numeric',
                'ancho_caseta' => 'nullable|numeric',
                'largo_caseta' => 'nullable|numeric',
                'alto_caseta' => 'nullable|numeric',
            ]);
    
            // Actualizar la parcela con los datos válidos
            $parcela->update($request->all());
    
            return response()->json(['message' => 'Parcela actualizada con éxito'], 200);
    
        } catch (ValidationException $e) {
            // Capturamos la excepción de validación
            $errors = $e->validator->errors()->all(); // Obtener solo los mensajes de error como un array
    
            // Retornamos la respuesta en el formato deseado
            return response()->json(['status' => 422, 'errors' => $errors], 422);
        } catch (Exception $e) {
            return response()->json(['status' => 500, 'mensaje' => $e->getMessage()]);
        }
    }
    public function obtenerFiltros (){
        $filtros = Filtro::all();
        return response()->json ($filtros, 200);
    }

    /**
     * Borrar una parcela.
     */
    public function borrar($id)
    {
        $parcela = Parcela::find($id);

        if (!$parcela) {
            return response()->json(['message' => 'Parcela no encontrada'], 404);
        }
        $parcela->filtros()->detach();

        $parcela->delete();

        return response()->json(['message' => 'Parcela eliminada con éxito'], 200);
    }

    /**
     * Devuelve todos los municipios de una provincia.
     * Ayuda a generar el número SIGPAC.
     */
    public function obtenerMunicipios($idProvincia)
    {
        $municipios = Municipio::where('id_provincia', $idProvincia)->get(['id', 'nombre']);
        if ($municipios->isEmpty()) {
            return response()->json(['message' => 'No se encontraron municipios para la provincia seleccionada'], 404);
        }

        return response()->json($municipios, 200);
    }

    /**
     * Devuelve toda la información de las provincias.
     */
    public function obtenerProvincias()
    {
        $provincias = Provincia::all();
        return response()->json($provincias, 200);
    }

    protected function generarInformeFiltros () {

    }
    protected function generarInformeCaseta () {

    }
    protected function generarInformeParcela() {
        
    }
 }
