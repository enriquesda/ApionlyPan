<?php

namespace App\Http\Controllers;

use App\Models\CultivoParcela;
use App\Models\Fertilizante;
use App\Models\FiltroParcela;
use App\Models\FitosanitarioCultivo;
use App\Models\MaquinaCultivo;
use App\Models\Riego;
use App\Models\Cultivo;
use App\Models\Fitosanitario;
use App\Models\GrupoBombeo;
use App\Models\Maquina;
use App\Models\Apero;
use App\Models\Espaldera;
use Illuminate\Support\Facades\Auth;
use Exception;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Request;

class CultivosController extends Controller //Controlador CultivoParcela
{
    // crear, editar, borrar, obtener (id_parcela, id_cultivo), dar de baja
   

    public function obtenerTiposCultivo (){
        $c = Cultivo::all();
        return response()->json($c, 200);
    }
    public function obtenerTiposRiego () {
        $f= Riego::all();
        return response()->json($f, 200);
    }
    public function obtenerGruposBombeo (){
        $f= GrupoBombeo::select(['id', 'potencia_bomba', 'cabeas'])->get();
        return response()->json($f, 200);
    }
    public function obtenerMaquinaria () {
        $f= Maquina::select(['id', 'nombre', 'tipo_cultivo', 'cv', 'kw'])->get();
        return response()->json($f, 200);
    }
    public function obtenerAperos (){
        $f= Apero::select(['id', 'nombre'])->get();
        return response()->json($f, 200);
    }
    public function obtenerEspalderas (){
        $f= Espaldera::all();
        return response()->json($f, 200);
    }

    public function obtenerTiposFitosanitarios(){
        $f= Fitosanitario::select(['id', 'nombre', 'materia_activa'])->get();
        return response()->json($f, 200);
    }
    public function obtenerSeleccionables () {
        try{
            $r= Riego::all();
            $g= GrupoBombeo::select(['id', 'potencia_bomba', 'cabeas'])->get();
            $m= Maquina::select(['id', 'nombre', 'tipo_cultivo', 'cv', 'kw'])->get();
            $a= Apero::select(['id', 'nombre'])->get();
            $e= Espaldera::all();
            $f= Fitosanitario::select(['id', 'nombre', 'materia_activa'])->get();
            $respuesta['riegos'] = $r;
            $respuesta['grupos'] = $g;
            $respuesta['maquinas'] = $m;
            $respuesta['aperos'] = $a;
            $respuesta['espalderas'] = $e;
            $respuesta['fitosanitarios'] = $f;
            return response()->json ($respuesta);        
            
        }catch (Exception $e){
            return response()->json(['status' => 500, 'mensaje' => $e->getMessage()]);
        }
    }
    /**
     * Obtiene todas los cultivo_parcela.
     */
    public function obtenerTodas()
    {
        $parcelas = CultivoParcela::all();
        return response()->json($parcelas, 200);
    }
    public function obtenerResumenCultivosParcela($idParcela)
    {
        // Obtener cultivos para un usuario específico
        $cultivos = CultivoParcela::where('id_parcela', $idParcela)
        ->with(['cultivo' => function ($query) {
            // Solo seleccionar el tipo de cultivo
            $query->select('id', 'nombre');
        }])->whereNull('fecha_baja')->select('id', 'id_cultivo', 'fecha_siembra', 'fecha_recoleccion')->get();

        return response()->json($cultivos, 200);
    }
     
    /**
     * Obtiene el cultivo de una parcela.
     */
    public function obtenerCultivoPorID($id){
        // Obtener cultivo con todas sus relaciones, pero sin cargar el informe_impacto
        $cultivo = CultivoParcela::with([
            'cultivo:id,nombre',
            'parcela:id,id_agricultor,nombre',
            'espaldera:id,nombre',
            'sistemaRiego:id,nombre',
            'grupoBombeo:id',
            'fertilizantes',
            'fitosanitarios:id,nombre,fitosanitarios_cultivo.n_aplicaciones,fitosanitarios_cultivo.fecha',
            'aperos:id,nombre,aperos_cultivo.pases,aperos_cultivo.fecha',
            'maquinas:id,nombre,maquinaria_cultivo.horas,maquinaria_cultivo.fecha',
        ])
        ->select('id', 'id_parcela', 'id_cultivo', 'fecha_siembra', 'fecha_recoleccion', 'espaldera', 'sistema_riego', 'bomba', 'entre_arboles', 'entre_calles', 'superficie_cultivada', 'produccion_t_ha', 'informe_impacto')
        ->findOrFail($id);
    
  // Extraer solo los datos de los pivotes
//   $fitosanitariosPivot = $cultivo->fitosanitarios->map(function ($item) {
//     return [
//         'id_cultivo_parcela' => $item->pivot->id_cultivo_parcela,
//         'id_fitosanitario' => $item->pivot->id_fitosanitario,
//         'n_aplicaciones' => $item->pivot->n_aplicaciones,
//         'fecha' => $item->pivot->fecha,
//     ];
// });

// $aperosPivot = $cultivo->aperos->map(function ($item) {
//     return [
//         'id_cultivo_parcela' => $item->pivot->id_cultivo_parcela,
//         'id_apero' => $item->pivot->id_apero,
//         'pases' => $item->pivot->pases,
//         'fecha' => $item->pivot->fecha,
//     ];
// });

// $maquinasPivot = $cultivo->maquinas->map(function ($item) {
//     return [
//         'id_cultivo_parcela' => $item->pivot->id_cultivo_parcela,
//         'id_maquina' => $item->pivot->id_maquina,
//         'horas' => $item->pivot->horas,
//         'fecha' => $item->pivot->fecha,
//     ];
// });

// Devolver solo los datos del pivote

        // Añadir una propiedad temporal `tiene_informe_impacto`
        $cultivo->tiene_informe_impacto = !is_null($cultivo->informe_impacto);

        // Eliminar el campo `informe_impacto` del resultado
        unset($cultivo->informe_impacto);
        
        // $cultivo-> fitosanitarios = $fitosanitariosPivot;
        //     $cultivo->aperos = $aperosPivot;
        //     $cultivo->maquinas = $maquinasPivot;
        
        return response()->json($cultivo, 200);
    }
    // public function obtenerPorId($idParcela)
    // {
    //     try {
           
    //         $cultivoParcela = CultivoParcela::with([
    //             'parcela',
    //             'cultivo',
    //             'espaldera',
    //             'sistemaRiego',
    //             'grupoBombeo',
    //             //'fertilizantes', //hay que arreglar esto
    //             //'fitosanitarios',
    //             'aperos',
    //             //'maquinas'
    //         ])->where('id_parcela', $idParcela)->where('fecha_baja', NULL)->get();

    //         return response()->json($cultivoParcela, 200);
    //     } catch (Exception $e) {
    //         return response()->json(['status' => 500, 'mensaje' => $e->getMessage()]);
    //     }
    // }

    /**
     * Inserta un  cultivo_parcela en una parcela.
     */
    public function crearCultivoParcela(Request $request)
    {
        try {
            $request->validate([
                'id_parcela' => 'required|integer|exists:parcelas,id', 
                'id_cultivo' => 'required|integer|exists:cultivos,id', 
                'fecha_baja' => 'nullable|date',
                'espaldera' => 'nullable|numeric', 
                'sistema_riego' => 'nullable|numeric', 
                'bomba' => 'nullable|integer|exists:grupos_bombeo,id', 
                'entre_arboles' => 'nullable|numeric|between:0,99999.99',
                'entre_calles' => 'nullable|numeric|between:0,99999.99', 
                'goteros_arbol' => 'nullable|numeric|between:0,10',
                'superficie_cultivada' => 'nullable|numeric|between:0,99999.99', 
                'produccion_t_ha' => 'nullable|numeric|between:0,99999.99',
            ]);

            // Comprobar si ya existe un registro con el mismo id_parcela y fecha_baja es NULL
            $existingCultivo = CultivoParcela::where(['id_parcela'=>$request->id_parcela, 'id_cultivo'=>$request->id_cultivo])
                ->whereNull('fecha_baja')
                ->first();

            if ($existingCultivo) {
                return response()->json(['status' => 422, 'message' => 'No se puede insertar: ya existe un registro con la misma parcela y fecha_baja es NULL.'], 422);
            }
            // Aquí puedes proceder con la inserción
            $cultivoParcela = CultivoParcela::create($request->all());

            $tipoCultivo = Cultivo::find ($request->id_cultivo);
            $cultivoParcela['cultivo'] = $tipoCultivo;
            return response()->json([
                'status' => true,
                'message' => 'Cultivo_parcela insertado con éxito',
                'datos' => $cultivoParcela
            ], 201);
        } catch (ValidationException $e) {
            // Capturamos la excepción de validación
            $errors = $e->validator->errors()->all(); // Obtener solo los mensajes de error como un array

            // Retornamos la respuesta en el formato deseado
            return response()->json(['status' => 422, 'errors' => $errors], 422);
        } catch (Exception $e) {
            return response()->json(['status' => 500, 'mensaje' => $e->getMessage()]);
        }
    }


    /**
     * Edita un  cultivo_parcela en una parcela.
     */
     public function editarCultivoParcela(Request $request, $id)
     {
         try {
             // Buscar el cultivo de la parcela por ID y verificar que no tenga fecha de baja
             $cultivoParcela = CultivoParcela::where('id', $id)
                 ->whereNull('fecha_baja')
                 ->first();
     
             if (!$cultivoParcela) {
                 return response()->json(['status' => 404, 'message' => 'Cultivo de parcela no encontrado.'], 404);
             }
     
             // Validar los datos de entrada
             $request->validate([
                 'id_parcela' => 'required|integer|exists:parcelas,id',
                 'id_cultivo' => 'required|integer|exists:cultivos,id',
                 'fecha_baja' => 'nullable|date',
                 'espaldera' => 'nullable|integer',
                 'id_filtro' => 'nullable|integer',
                 'fecha_siembra'=>'nullable|date',
                 'fecha_recoleccion'=>'nullable|date',
                 'id_maquina' => 'nullable|integer',
                 'horas_maquina' => 'nullable|integer',
                 'sistema_riego' => 'nullable|integer',
                 'bomba' => 'nullable|integer|exists:grupos_bombeo,id',
                 'entre_arboles' => 'nullable|numeric|between:0,99999.99',
                 'entre_calles' => 'nullable|numeric|between:0,99999.99',
                 'goteros_arbol' => 'nullable|numeric|between:0,10',
                 'superficie_cultivada' => 'nullable|numeric|between:0,99999.99',
                 'produccion_t_ha' => 'nullable|numeric|between:0,99999.99',
             ]);
     
             // Filtrar solo los datos correspondientes a CultivoParcela y actualizarlos
             $cultivoData = $request->only([
                 'id_parcela', 'id_cultivo', 'fecha_baja', 'espaldera', 'id_filtro', 
                 'id_maquina', 'horas_maquina', 'sistema_riego', 'bomba', 'entre_arboles', 
                 'entre_calles', 'superficie_cultivada', 'produccion_t_ha', 'fecha_siembra', 'fecha_recoleccion'
             ]);
             $cultivoParcela->update($cultivoData);
     
             // Llamar a las funciones que manejan las relaciones
             if ($request->has('fertilizantes')) {
                 $this->insertarFertilizantes($cultivoParcela, $request->fertilizantes);
             }
             if ($request->has('fitosanitarios')) {
                 $this->insertarFitosanitarios($cultivoParcela, $request->fitosanitarios);
             }
             if ($request->has('aperos')) {
                 $this->insertarPasesAperos($cultivoParcela, $request->aperos);
             }
             if ($request->has('maquinas')) {
                 $this->insertarHorasTransporteMaquinas($cultivoParcela, $request->maquinas);
             }
     
             return response()->json(['status' => true, 'message' => 'Cultivo de parcela actualizado con exito', 'datos' => $cultivoParcela], 200);
     
         } catch (ValidationException $e) {
             $errors = $e->validator->errors()->all();
             return response()->json(['status' => 422, 'errors' => $errors], 422);
         } catch (Exception $e) {
             return response()->json(['status' => 500, 'mensaje' => $e->getMessage()]);
         }
     }

     public function eliminarCultivo ($id){
        try{
            $c = CultivoParcela::find ($id);
            if ($c){
                if ($c->fecha_baja==null){ //primero soft-delete
                    $c->fecha_baja = now();
                    $c->save();
                }else{ //si ya se ha puesto fecha_baja previamente borramos definitivamente
                     // Desasociar todas las relaciones de muchos a muchos para evitar restricciones de clave foránea
                    $c->fertilizantes()->detach();
                    $c->fitosanitarios()->detach();
                    $c->aperos()->detach();
                    $c->maquinas()->detach();

                    // Eliminación definitiva
                    $c->delete();
                }
                return response()->json(['status' => 200, 'mensaje' => 'Eliminado'], 200);
            }else{
                return response()->json(['status' => 402, 'mensaje' => 'No se encuentra el cultivo']);
            }
        }catch (Exception $e){
            return response()->json(['status' => 500, 'mensaje' => $e->getMessage()]);

        }
     }

     protected function insertarFertilizantes($cultivoParcela, $fertilizantes)
    {
        foreach ($fertilizantes as $fertilizante) {
            $cultivoParcela->fertilizantes()->updateOrCreate(
                ['id_fertilizante' => $fertilizante['id']],
                ['cantidad' => $fertilizante['cantidad']]
            );
        }
    }


    protected function insertarFitosanitarios($cultivoParcela, $fitosanitarios)
    {
        $conta = 0;
        
        foreach ($fitosanitarios as $fitosanitario) {
            $syncDat[$conta]=([
                    'id_fitosanitario' => $fitosanitario['id'],
                    'n_aplicaciones' => $fitosanitario['n_aplicaciones'],
                    'fecha' => isset($fitosanitario['fecha']) ? substr($fitosanitario ['fecha'],0,10) : now()
                ]
            );
            $conta++;
        }

        $cultivoParcela->fitosanitarios()->sync($syncDat);
    }

    public function agregarInforme (Request $request) {
		try{
			// $validatedData = Validator::make($request->all(),[
			// 	'archivo' => 'required|file',
			// 	'id_factura' => 'required|integer',
			// 	'nombre' => 'required|string|max:255'
			// ]);
			// if ($validatedData->fails()){
			// 	$respuesta = array('estado' => false, 'mensaje' => erroresFormulario($validatedData->errors()->all()), 'code'=>200);
			// }
			//return response()->json ($request);
			$arvicho = $request->file('archivo');///EL ARVHICHO HOEPUTA sin el validator no funciona no me preguntes porque...
			if (!$arvicho){
				$arvicho = $request -> input ('archivo'); //esto debería petar porque debe ser explicitamente un file para poder obtener el content
			}
			$content = file_get_contents($arvicho->getRealPath()); //necesito usar esta función para almacenar el contenido del archivo en una entrada de la tabla
			$c_p = CultivoParcela::find ($request->id);
			
			$c_p -> informe_impacto = $content;
			if ($c_p->save()){
                $respuesta = array ('estado'=> true , 'status' => 201, 'mensaje'=>'Informe añadido');
            }else{
                $respuesta = array ('estado'=>false, 'stauts'=>300, 'mensaje'=>'No se ha podido añadir el archivo');
            }

			
			return response()->json($respuesta);
			//return response($content)->header ('Content-Type', 'application/pdf');
		} catch (Exception $e) {
			
			LogController::errores('[AÑADIR ARCHIVO A FACTURA EXTERNA] ' . $e->getMessage());
			return response()->json(['estado' => false, 'mensaje' => $e->getMessage(), 'e' => $e->getTraceAsString()], 200);
		}
	}
	public function obtenerArchivo($id)
    {
            try {
                // Obtener solo el campo `informe_impacto` del cultivo por su ID
                $cultivo = CultivoParcela::select('informe_impacto')->findOrFail($id);

                // Asegurarse de que el archivo exista
                if (is_null($cultivo->informe_impacto)) {
                    return response()->json(['estado' => false, 'mensaje' => 'El archivo no existe.'], 404);
                }

                // Devolver el archivo con el tipo de contenido adecuado
                return response($cultivo->informe_impacto)
                    ->header('Content-Type', 'application/pdf')
                    ->header('Content-Disposition', 'inline; filename="informe_impacto_'.$id.'.pdf"');

            } catch (Exception $e) {
                // Log de errores y respuesta en caso de excepción
                LogController::errores('[OBTENER ARCHIVO] ' . $e->getMessage());
                return response()->json(['estado' => false, 'mensaje' => $e->getMessage(), 'e' => $e->getTraceAsString()], 500);
            }
    }

	public function borrarArchivo ($id){
		try{
			 // Obtener solo el campo `informe_impacto` del cultivo por su ID
             $archivoCultivo = CultivoParcela::where('id',$id)->update('informe_impacto', null);

			//$content = file_get_contents($arvicho->archivo);
			if ($archivoCultivo > 0){
				$respuesta = array ('estado'=> true , 'status' => 200, 'mensaje'=>'Se ha eliminado correctamente el archivo');
			}else{
				$respuesta = array ('estado'=> true , 'status' => 204, 'mensaje'=>'No se ha eliminado nigun archivo');
			}
			return response()->json($respuesta);
			//return response($content)->header ('Content-Type', 'application/pdf');
		} catch (Exception $e) {
			//dd(e);
			LogController::errores('[ELIMINANDO ARCHIVO] ' . $e->getMessage());
			return response()->json(['estado' => false, 'mensaje' => $e->getMessage(), 'e' => $e->getTraceAsString()], 200);
		}
	}

    protected function insertarPasesAperos($cultivoParcela, $aperos)
    {
        $conta=0;
       foreach ($aperos as $apero) {
        
            $syncData[$conta]=(['id_apero'=>$apero['id'],
            'pases' => $apero['pases'],
            'fecha' => isset($aperos['fecha']) ? substr($apero['fecha'], 0, 10) : now()->toDateString(),
             ]);
             $conta++;
         }
        //  dd($syncData);
        $cultivoParcela -> aperos ()->sync($syncData);
            // $cultivoParcela->aperos()->sync([
            
            //   $apero['id'] => [
            //     ['pases' => $apero['pases'],
            //         'fecha' =>isset($apero['fecha']) ? substr($apero['fecha'], 0,10): now()
            //     ]
            // ]]);
            
        //}
    }


    protected function insertarHorasTransporteMaquinas($cultivoParcela, $maquinas)
    {
        $conta = 0;
        foreach ($maquinas as $maquina) {
            $syncData[$conta]=([
                 'id_maquina'=> $maquina['id'],
                    'horas' => $maquina['horas'],
                    'fecha' => isset($maquina['fecha']) ? substr($maquina['fecha'],0, 10) : now(),
                ]
            );
            $conta++;
        }
        $cultivoParcela->maquinas()->sync($syncData);
    }
    protected function generarInformeRiegos () {

    }
    protected function generarInformeEspalderas () {

    }
    protected function generarInformeFitosanitarios () {

    }
    protected function generarInformeFertilizantes (){

    }
    protected function generarInformeAperos () {

    }
    protected function generarInformeMaquinaria () {
    
    }
    public function generarInformeCultivo () {
        $informe = [];
        $informe['riegos'] = $this->generarInformeRiegos();
        $informe['espalderas'] = $this->generarInformeEspalderas();
        $informe['fitosanitarios'] = $this->generarInformeFitosanitarios();
        $informe['fertilizantes'] = $this->generarInformeFertilizantes();
        $informe['aperos'] = $this->generarInformeAperos();
        $informe['maquinaria'] = $this->generarInformeMaquinaria();
        $informe['filtros'] = $this->generarInformeFiltros();
        $informe['caseta_riego'] = $this->generarInformeCasetaRiego(); //Estos que pertenecerían al controlador de parcela al final los voy a meter dentro de este controlador para centralizar
    
        return $informe;
    }
    
   
   
}
