<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Tymon\JWTAuth\Facades\JWTAuth ;
use Exception;


class cultivos
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        try{

        
        $user = JWTAuth::parseToken()->authenticate();
        //$esPropietario 
			
			// if (($user->role == 1 || $user->role == 2) || $esPropietario){
				
			// }else if ()

        return $next($request);
        }catch (Exception $e){

            return response()->json (["mensaje"=> $e->getMessage() ],300);
        }


    }
}
