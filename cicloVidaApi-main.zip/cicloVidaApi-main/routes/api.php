<?php

use App\Http\Controllers\CultivosController;
use App\Http\Controllers\UsersController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Middleware\Cors;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });ç
Route::post('usuario/login', 'UsersController@login');

Route::post('usuario/recuperar', 'UsersController@recuperarContrasen');
Route::post ('usuario/registro', 'UsersController@registrarUsuarioAgricultor');


 Route::group(['middleware' => ['jwt.verify', 'cors']], function () {
// Logear en la aplicación
//Route::post('usuario/login', 'UserController@authenticate');

Route::get('usuario/obtener/{idInicio?}', 'UsersController@obtenerUsuariosConAgricultores'); //esto es solo para administradores
Route::get('usuario/buscador/{termino?}', [UsersController::class, 'buscarUsuarios']);
Route::post('usuario/nuevo', 'UsersController@crearUsuario');
Route::put('usuario/editar', 'UsersController@editarUsuario');
Route::put('usuario/cambiarPass', 'UsersController@cambiarContrasen');
Route::post('usuario/valido', 'UsersController@validaUsuario');
Route::delete('usuario/eliminar/{id}', 'UsersController@eliminarUsuario');
Route::post ('usuario/logout', 'UsersController@logout');

//recuperar contraseña se implementará más adelante

//rutas del controlador de agricultores
Route::get('agricultor/obtener', 'AgricultoresController@obtener');
Route::get('agricultor/obtener/{id}', 'AgricultoresController@obtenerPorId');
Route::get('agricultor/obtenerMaquinas', 'AgricultoresController@obtenerTodasLasMaquinas');
Route::get('agricultor/obtenerAperos', 'AgricultoresController@obtenerTodosLosAperos');
Route::get('agricultor/obtenerMyA/{idAgricultor}', 'AgricultoresController@obtenerMaquinasyAperosAgricultor'); //obtener maquinas y aperos de un agricultor
Route::post('agricultor/nuevo', 'AgricultoresController@crear');
Route::post('agricultor/addMaquina/{idAgricultor}/{idMaquina}', 'AgricultoresController@agregarMaquina');
Route::post('agricultor/addApero/{idAgricultor}/{idApero}', 'AgricultoresController@agregarApero');
Route::put('agricultor/editar', 'AgricultoresController@editar');
Route::delete('agricultor/eliminar/apero/{idAgricultor}/{idApero}', 'AgricultoresController@eliminarApero');
Route::delete('agricultor/eliminar/maquina/{idAgricultor}/{idMaquina}', 'AgricultoresController@eliminarMaquina');
Route::delete('agricultor/eliminar/{id}', 'AgricultoresController@borrar');

//rutas del controlador de parcelas
Route::get('parcelas', 'ParcelasController@obtenerTodas');
Route::get('parcelas/agricultor/{idAgricultor}', 'ParcelasController@obtenerParcelasAgricultor');
Route::post('parcelas/nueva', 'ParcelasController@crearParcela');
Route::post ('parcelas/agregarFiltros/{idParcela}', 'ParcelasController@agregarFiltrosParcela');
Route::put ('parcelas/editarFiltros/{idParcela}', 'ParcelasController@actualizarFiltrosParcela'); //redibe un array con los nuevos filtros eliminando los que hubiera previamente
Route::put('parcelas/editar', 'ParcelasController@editar');
Route::delete('parcelas/eliminar/{id}', 'ParcelasController@borrar');
Route::get('municipios/provincia/{idProvincia}', 'ParcelasController@obtenerMunicipios');
Route::get('provincias', 'ParcelasController@obtenerProvincias');
Route::get('filtros', 'ParcelasController@obtenerFiltros');

//rutas del controlador de Cultivos ( cultivo_parcela)

Route::get('cultivos_parcelas', 'CultivosController@obtenerTodas');
Route::get('cultivos/parcela/{id}', 'CultivosController@obtenerResumenCultivosParcela');
Route::get('cultivo/{id}', 'CultivosController@obtenerCultivoPorId');
Route::delete('cultivo/eliminar/{id}', 'CultivosController@eliminarCultivo');

Route::get ('cultivos/tipos', 'CultivosController@obtenerTiposCultivo');
Route::get ('cultivos/fitosanitarios', 'CultivosController@obtenerTiposFitosanitarios');
Route::post('cultivo/nuevo', 'CultivosController@crearCultivoParcela');
Route::put('cultivo/editar/{id}', 'CultivosController@editarCultivoParcela');

Route::get('cultivos/seleccionables', [CultivosController::class, 'obtenerSeleccionables']);
 });
