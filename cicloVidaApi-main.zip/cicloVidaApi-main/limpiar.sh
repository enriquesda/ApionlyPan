php artisan cache:clear #
php artisan config:cache #
php artisan view:clear #
php artisan route:cache #

rm storage/logs/*.log #